import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from bulk_api.common import Side, OrderStatus


@dataclass
class OrderState:
    """Represents an order status update"""
    timestamp: int
    symbol: str
    order_id: str
    status: OrderStatus
    side: Side
    price: float
    vwap: float
    size: float
    size_done: float
    size_orig: float
    is_maker: bool
    error: Optional[str] = None
    order_type: Optional[str] = None   # ← NEW: 'ot' field
    reduce_only: bool = False          # ← NEW: 'r' field
    tif: Optional[str] = None         # ← NEW: 'tif' field

    def get_side(self) -> Side:
        """Get the order side"""
        return Side.BUY if self.is_buy else Side.SELL

    def amount_remaining(self) -> float:
        """Get the amount of remaining to be filled"""
        return max(self.size - self.size_done, 0.0)

    @classmethod
    def from_api(cls, data: Dict) -> 'OrderState':
        signed_sz = data.get('sz', 0.0)
        return cls(
            timestamp=data.get('ts'),                              # 'timestamp' → 'ts'
            symbol=data.get('sym'),                                # 'symbol'    → 'sym'
            order_id=data.get('oid'),                              # 'orderId'   → 'oid'
            status=OrderStatus.from_string(data.get('status')),
            side=Side.BUY if signed_sz >= 0 else Side.SELL,        # derived from sign of 'sz'
            price=data.get('px'),                                  # 'price'     → 'px'
            vwap=data.get('vwap', 0.0),
            size=abs(signed_sz),                                   # magnitude of signed 'sz'
            size_done=data.get('fillSz', 0.0),                     # 'filledSize' → 'fillSz'
            size_orig=data.get('origSz', abs(signed_sz)),          # 'originalSize' → 'origSz'
            is_maker=data.get('mk', False),                        # 'maker'     → 'mk'
            error=data.get('reason'),
            order_type=data.get('ot'),
            reduce_only=data.get('r', False),
            tif=data.get('tif'),
        )

@dataclass
class Margin:
    """Account-level margin information"""
    total_margin: float
    available_margin: float
    execution_impact: float
    transferable_balance: float
    margin_used: float
    margin_buffer_rate: float
    buffered_margin: float
    notional: float
    realized_pnl: float
    unrealized_pnl: float
    fees: float
    funding: float

    @classmethod
    def from_api(cls, data: Dict) -> 'Margin':
        return cls(
            total_margin=data.get('totalMargin', data.get('totalBalance', 0.0)),
            available_margin=data.get('availableMargin', data.get('availableBalance', 0.0)),
            execution_impact=data.get('executionImpact', 0.0),
            transferable_balance=data.get('transferableBalance', 0.0),
            margin_used=data.get('marginUsed', 0.0),
            margin_buffer_rate=data.get('marginBufferRate', 0.0),
            buffered_margin=data.get('bufferedMargin', 0.0),
            notional=data.get('notional', 0.0),
            realized_pnl=data.get('realizedPnl', 0.0),
            unrealized_pnl=data.get('unrealizedPnl', 0.0),
            fees=data.get('fees', 0.0),
            funding=data.get('funding', 0.0)
        )


@dataclass
class Position:
    """Position information with full risk metrics"""
    symbol: str
    size: float  # Positive for long, negative for short
    price: float  # Volume-weighted average price (entry price)
    fair_price: float  # Current fair/mark price
    notional: float  # size × fair_price
    realized_pnl: float
    unrealized_pnl: float
    leverage: float
    liquidation_price: float
    fees: float
    funding: float
    maintenance_margin: float
    lambda_: float  # Lambda value (risk parameter)
    risk_allocation: float  # C_i

    @classmethod
    def from_api(cls, data: Dict) -> 'Position':
        return cls(
            symbol=data.get('symbol', ''),
            size=data.get('size', 0.0),
            price=data.get('price', 0.0),
            fair_price=data.get('fairPrice', 0.0),
            notional=data.get('notional', 0.0),
            realized_pnl=data.get('realizedPnl', 0.0),
            unrealized_pnl=data.get('unrealizedPnl', 0.0),
            leverage=data.get('leverage', 0.0),
            liquidation_price=data.get('liquidationPrice', 0.0),
            fees=data.get('fees', 0.0),
            funding=data.get('funding', 0.0),
            maintenance_margin=data.get('maintenanceMargin', 0.0),
            lambda_=data.get('lambda', 0.0),
            risk_allocation=data.get('riskAllocation', 0.0)
        )

    def is_long(self) -> bool:
        """Check if position is long"""
        return self.size > 0

    def is_short(self) -> bool:
        """Check if position is short"""
        return self.size < 0


@dataclass
class LeverageSetting:
    """Leverage setting for a symbol"""
    symbol: str
    leverage: float  # 1.0 to 50.0

    @classmethod
    def from_api(cls, data: Dict) -> 'LeverageSetting':
        return cls(
            symbol=data.get('symbol') or data.get('coin', ''),   # ← handle 'coin' alias
            leverage=data.get('leverage', 1.0)
        )

@dataclass
class CommissionApproval:
    """Approved builder-code recipient for account-routed order flow"""
    recipient: str
    max_fee: int

    @classmethod
    def from_api(cls, data: Dict) -> 'CommissionApproval':
        return cls(
            recipient=data.get('recipient', ''),
            max_fee=data.get('maxFee', data.get('max_fee', 0))
        )


@dataclass
class AccountSnapshot:
    """Complete account state snapshot"""
    margin: Margin
    positions: List[Position]
    open_orders: List[OrderState]
    leverage_settings: List[LeverageSetting]
    commission_approvals: List[CommissionApproval] = field(default_factory=list)
    timestamp: int = field(default_factory=lambda: int(time.time() * 1000))

    @classmethod
    def from_api(cls, data: Dict) -> 'AccountSnapshot':
        return cls(
            margin=Margin.from_api(data.get('margin', {})),
            positions=[Position.from_api(pos) for pos in data.get('positions', [])],
            open_orders=[OrderState.from_api(order) for order in data.get('openOrders', [])],
            leverage_settings=[LeverageSetting.from_api(lev) for lev in data.get('leverageSettings', [])],
            commission_approvals=[
                CommissionApproval.from_api(approval)
                for approval in data.get('builderCodeApprovals', [])
            ],
        )

    def get_position(self, symbol: str) -> Optional[Position]:
        """Get position for a specific symbol"""
        for pos in self.positions:
            if pos.symbol == symbol:
                return pos
        return None

    def get_leverage_setting(self, symbol: str) -> Optional[LeverageSetting]:
        """Get leverage setting for a specific symbol"""
        for lev in self.leverage_settings:
            if lev.symbol == symbol:
                return lev
        return None


@dataclass
class MarginUpdate:
    """Real-time margin update"""
    total_margin: float
    available_margin: float
    execution_impact: float
    transferable_balance: float
    margin_used: float
    margin_buffer_rate: float
    buffered_margin: float
    notional: float
    realized_pnl: float
    unrealized_pnl: float
    fees: float
    funding: float

    @classmethod
    def from_api(cls, data: Dict) -> 'MarginUpdate':
        return cls(
            total_margin=data.get('totalMargin', data.get('totalBalance', 0.0)),
            available_margin=data.get('availableMargin', data.get('availableBalance', 0.0)),
            execution_impact=data.get('executionImpact', 0.0),
            transferable_balance=data.get('transferableBalance', 0.0),
            margin_used=data.get('marginUsed', 0.0),
            margin_buffer_rate=data.get('marginBufferRate', 0.0),
            buffered_margin=data.get('bufferedMargin', 0.0),
            notional=data.get('notional', 0.0),
            realized_pnl=data.get('realizedPnl', 0.0),
            unrealized_pnl=data.get('unrealizedPnl', 0.0),
            fees=data.get('fees', 0.0),
            funding=data.get('funding', 0.0)
        )


@dataclass
class PositionUpdate:
    """Real-time position update"""
    symbol: str
    size: float
    price: float
    realized_pnl: float
    unrealized_pnl: float
    leverage: float
    liquidation_price: float
    fair_price: float
    notional: float
    fees: float
    funding: float
    maintenance_margin: float
    lambda_: float
    risk_allocation: float

    @classmethod
    def from_api(cls, data: Dict) -> 'PositionUpdate':
        return cls(
            symbol=data.get('symbol', ''),
            size=data.get('size', 0.0),
            price=data.get('price', 0.0),
            realized_pnl=data.get('realizedPnl', 0.0),
            unrealized_pnl=data.get('unrealizedPnl', 0.0),
            leverage=data.get('leverage', 0.0),
            liquidation_price=data.get('liquidationPrice', 0.0),
            fair_price=data.get('fairPrice', 0.0),
            notional=data.get('notional', 0.0),
            fees=data.get('fees', 0.0),
            funding=data.get('funding', 0.0),
            maintenance_margin=data.get('maintenanceMargin', 0.0),
            lambda_=data.get('lambda', 0.0),
            risk_allocation=data.get('riskAllocation', 0.0)
        )
